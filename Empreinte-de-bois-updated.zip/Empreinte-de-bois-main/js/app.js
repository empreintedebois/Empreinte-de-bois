// js/app.js
// Point d'entrée unique pour le runtime du site.
// Les modules importés s'auto-initialisent à l'import.

import "./background-canvas.js";
import "./page.js";
import "./gallery.js";
