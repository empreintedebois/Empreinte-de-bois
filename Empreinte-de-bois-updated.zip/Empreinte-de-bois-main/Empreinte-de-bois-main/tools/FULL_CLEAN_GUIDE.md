# Full Clean - Guide

## What to delete BEFORE applying the FULL CLEAN ZIP
- Run the cleanup workflow (optional) or delete manually using tools/cleanup_plan.yml.
- Key deletions:
  - assets/materiaux/** (duplicate of bandeaux)
  - All image variants *_w640.webp, *_w450.webp, full/, thumb/
  - Any .png/.gif leftovers in assets/bandeaux/M**/
  - hero-bg_w*.webp and logo_w*.webp (keep canonical assets/hero-bg.webp and assets/logo.webp)
  - assets/bandeaux/bandeaux-config.json
  - assets/manifest/sizes.json

## Canonical paths after clean
- Bandeaux: assets/bandeaux/Mxx/image.webp (one file per model)
- Hero background: assets/hero-bg.webp
- Logo: assets/logo.webp
- Materials cards now reuse bandeaux images (config/materials.json updated)

## Note about matrix
- The matrice folder is preserved for later use.
