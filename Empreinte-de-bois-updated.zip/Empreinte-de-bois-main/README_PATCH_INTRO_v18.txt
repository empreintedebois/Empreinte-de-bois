Copier ces fichiers en écrasant:
- index.html
- assets/intro/intro.js
- assets/intro/intro.css
