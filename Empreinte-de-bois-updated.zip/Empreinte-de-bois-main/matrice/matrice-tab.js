
// Already handled inline by script.js open/close; keep file to satisfy includes.
