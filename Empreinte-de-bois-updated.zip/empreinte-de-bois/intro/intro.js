
const state={logosReady:false,shardsReady:false};

function waitImg(i){return i.decode?i.decode():new Promise(r=>i.onload=r);}

async function loadLogos(){
 const imgs=document.querySelectorAll('.logo-text,.logo-motif');
 await Promise.all([...imgs].map(waitImg));
 state.logosReady=true;
}

async function loadShards(){
 const s=document.querySelectorAll('.shard');
 await Promise.all([...s].map(waitImg));
 state.shardsReady=true;
}

async function start(){
 await loadLogos();
 document.body.classList.add('intro-visible');
 loadShards();
 await new Promise(r=>{
   const t=setInterval(()=>{if(state.shardsReady){clearInterval(t);r();}},50);
 });
 document.body.classList.add('shards-visible');
 document.body.classList.add('explode');
 setTimeout(()=>document.body.classList.add('recoil'),1500);
 setTimeout(()=>document.body.classList.add('merge'),2500);
}

window.addEventListener('DOMContentLoaded',start);
