
PATCH INTRO v17
Arborescence root: empreinte-de-bois/

- G0 sans shards visibles
- G1 fade text + motif
- T0 attente chargement shards
- T4 fusion sans tremblement

Copier le dossier intro/ à la racine du projet.
