PATCH INTRO v17 — arborescence demandée

Root:
- index.html

Assets:
- assets/intro/intro.js
- assets/intro/intro.css
- (référence) assets/intro/assets/  <-- vos images + shards_meta.json + shards/

A appliquer:
1) Copier index.html à la racine (si vous utilisez déjà un index, mergez uniquement les 3 <img> + shards-layer + includes CSS/JS)
2) Copier assets/intro/ dans votre dossier assets/ (écraser).
